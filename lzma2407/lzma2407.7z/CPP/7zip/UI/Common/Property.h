// Property.h

#ifndef ZIP7_INC_7Z_PROPERTY_H
#define ZIP7_INC_7Z_PROPERTY_H

#include "../../../Common/MyString.h"

struct CProperty
{
  UString Name;
  UString Value;
};

#endif
